/*
 * HCSR04.h
 *
 *  Created on: Nov 26, 2023
 *      Author: Accelerator
 */

#ifndef HCSR04_H_
#define HCSR04_H_

#include "gpio.h"
#include "tim.h"

#define TRIG_PIN GPIO_PIN_15
#define TRIG_PORT GPIOB

void delay(uint16_t time);
void HCSR04_Read (void);

#endif /* HCSR04_H_ */
