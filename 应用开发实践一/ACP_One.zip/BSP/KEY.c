/*
 * KEY.c
 *
 *  Created on: Nov 15, 2023
 *      Author: Accelerator
 */

#include "KEY.h"

uint8_t KEY_SCAN(void)
{
	uint8_t key_val=0;
	if(HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin)==GPIO_PIN_RESET)
		key_val=1;
	if(HAL_GPIO_ReadPin(KEY2_GPIO_Port, KEY2_Pin)==GPIO_PIN_RESET)
		key_val=2;
	if(HAL_GPIO_ReadPin(KEY3_GPIO_Port, KEY3_Pin)==GPIO_PIN_RESET)
		key_val=3;
	if(HAL_GPIO_ReadPin(KEY4_GPIO_Port, KEY4_Pin)==GPIO_PIN_RESET)
		key_val=4;
	return key_val;
}
