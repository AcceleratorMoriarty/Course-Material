/*
 * BEEP.h
 *
 *  Created on: Nov 15, 2023
 *      Author: Accelerator
 */

#ifndef BEEP_H_
#define BEEP_H_

#include "gpio.h"
void BEEP_On(void);
void BEEP_Off(void);

#endif /* BEEP_H_ */
