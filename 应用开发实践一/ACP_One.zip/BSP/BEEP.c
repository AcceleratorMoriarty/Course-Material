/*
 * BEEP.c
 *
 *  Created on: Nov 15, 2023
 *      Author: Accelerator
 */

#include "BEEP.h"
void BEEP_On(void)
{
	HAL_GPIO_WritePin(BEEP_GPIO_Port, BEEP_Pin, GPIO_PIN_SET);
}
void BEEP_Off(void)
{
	HAL_GPIO_WritePin(BEEP_GPIO_Port, BEEP_Pin, GPIO_PIN_RESET);
}
