/*
 * KEY.h
 *
 *  Created on: Nov 15, 2023
 *      Author: Accelerator
 */

#ifndef KEY_H_
#define KEY_H_

#include "gpio.h"
uint8_t KEY_SCAN(void);


#endif /* KEY_H_ */
