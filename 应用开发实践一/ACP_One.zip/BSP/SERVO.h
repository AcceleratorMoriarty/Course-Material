/*
 * SERVO.h
 *
 *  Created on: Nov 15, 2023
 *      Author: Accelerator
 */

#ifndef SERVO_H_
#define SERVO_H_

#include "tim.h"

void SERVO_Init(void);
void SERVO_Set(uint8_t val);


#endif /* SERVO_H_ */
