/*
 * FAN.h
 *
 *  Created on: Nov 15, 2023
 *      Author: Accelerator
 */

#ifndef FAN_H_
#define FAN_H_

#include "gpio.h"
void FAN_On(void);
void FAN_Off(void);

#endif /* FAN_H_ */
