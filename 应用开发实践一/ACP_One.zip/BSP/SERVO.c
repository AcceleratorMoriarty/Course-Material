/*
 * SERVO.c
 *
 *  Created on: Nov 15, 2023
 *      Author: Accelerator
 */

#include "SERVO.h"

void SERVO_Init(void)
{
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
}
void SERVO_Set(uint8_t val)
{
	__HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_1,val);
}
