/*
 * FAN.c
 *
 *  Created on: Nov 15, 2023
 *      Author: Accelerator
 */

#include "FAN.h"

void FAN_On(void)
{
	HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, GPIO_PIN_SET);
}
void FAN_Off(void)
{
	HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, GPIO_PIN_RESET);
}
