/*
 * DHT11.h
 *
 *  Created on: Nov 15, 2023
 *      Author: Accelerator
 */

#ifndef DHT11_H_
#define DHT11_H_

/* Private includes ----------------------------------------------------------*/
#include "main.h"
#include "gpio.h"
#include "stdio.h"
#include "tim.h"
#include "stm32f1xx.h"
/* Private define ------------------------------------------------------------*/
#define DHT11_PIN_SET   HAL_GPIO_WritePin(GPIOB,GPIO_PIN_9,GPIO_PIN_SET)                                            //  ����GPIOΪ��
#define DHT11_PIN_RESET HAL_GPIO_WritePin(GPIOB,GPIO_PIN_9,GPIO_PIN_RESET)                                          //  ����GPIOΪ��                                                         //  DHT11 GPIO����



/* Private function prototypes -----------------------------------------------*/
//void DHT11(void);
void DHT11_START(void);
unsigned char DHT11_READ_BIT(void);
unsigned char DHT11_READ_BYTE(void);
unsigned char DHT11_READ_DATA(uint8_t *h);
unsigned char DHT11_Check(void);

void delay_us(uint32_t us);
#endif /* DHT11_H_ */
