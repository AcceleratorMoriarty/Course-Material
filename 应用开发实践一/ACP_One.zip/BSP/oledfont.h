/*
 * oledfont.h
 *
 *  Created on: Nov 15, 2023
 *      Author: Accelerator
 */

#ifndef OLEDFONT_H_
#define OLEDFONT_H_

extern const unsigned char F6x8[][6];
extern const unsigned char F8X16[];
extern const unsigned char Hzk[][32];
//extern unsigned char BMP1[];
//extern unsigned char BMP2[].........

#endif /* OLEDFONT_H_ */
