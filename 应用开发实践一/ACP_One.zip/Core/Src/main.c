/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "string.h"
#include "OLED.h"
#include "LED.h"
#include "KEY.h"
#include "FAN.h"
#include "BEEP.h"
#include "SERVO.h"
#include "DHT11.h"
#include "HCSR04.h"




/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

  uint32_t count=0;

  //��������
  uint8_t key_val,key_down,key_up,key_old;
  __IO uint32_t uwtick_key = 0;
  uint8_t oled_str[32];

  //DHT11
  float Humidity=40,d1,Tempt=20,d3;

  uint8_t b[3];

  extern uint8_t Distance;

  //�趨����
  float set_Humidity=30,set_Tempt=30;
  uint8_t set_Distance=20;

  uint8_t menu_flag=1;
  uint8_t DHT11_flag=0;
  uint8_t Set_flag=0;

  uint8_t rx_buffer;
  char tx[50];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

void Key_Proc(void);
void Oled_Proc(void);
void App_Proc(void);
void DHT11_Proc(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C2_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  //OLED��ʼ��
   OLED_Init();
   OLED_Clear();//����

   LED_Init();
   SERVO_Init();

   HAL_TIM_IC_Start_IT(&htim1, TIM_CHANNEL_1);
   HAL_UART_Receive_IT(&huart1,&rx_buffer,1);
   HAL_UART_Receive_IT(&huart2,&rx_buffer,1);



  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
//	  menu_flag=0;
//	  DHT11_flag=1;
	  HCSR04_Read();
	  Key_Proc();

	  Oled_Proc();
	  App_Proc();
	  if(DHT11_flag==1)
	  {
		  if(DHT11_READ_DATA(b)) //����1�ɹ�������ʧ��
		  {
			  d1 = b[1];
			  d3 = b[3];
			  Humidity=b[0]+d1/10;
			  Tempt= b[2]+d3/10;
		  }
	  }
	  sprintf(tx,"%d,%f,%f\r\n",Distance,Tempt,Humidity);
	  HAL_UART_Transmit(&huart1, (const uint8_t*)tx, strlen((const char*)tx), 50);



    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */



void App_Proc(void)
{
	if(Humidity<set_Humidity)
	{
		LED_On(2);
		SERVO_Set(100);
		HAL_Delay(50);
		SERVO_Set(200);
	}
	else
	{
		LED_Off(2);
	}
	if(Tempt>set_Tempt)
	{
		FAN_On();
		LED_On(1);
	}
	else
	{
		FAN_Off();
		LED_Off(1);
	}
	if(Distance<set_Distance)
	{
		LED_On(3);
		BEEP_On();
	}
	else
	{
		LED_Off(3);
		BEEP_Off();
	}
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance==USART1)
	{
		if(rx_buffer=='1')
		{
			sprintf(tx,"usart1_success\n");
		}
		else
		{
			sprintf(tx,"usart1_error\n");
		}

		HAL_UART_Transmit(&huart1, (const uint8_t*)tx, strlen((const char*)tx), 50);
		HAL_UART_Receive_IT(&huart1,&rx_buffer,1);
	}
	else if(huart->Instance==USART2)
	{
		if(rx_buffer=='1')
		{
			sprintf(tx,"success\n");
			HAL_UART_Transmit(&huart2, (const uint8_t*)tx, strlen((const char*)tx), 50);
		}
		else if(rx_buffer=='d')
		{
			sprintf(tx,"D: %d \r\n",Distance);
			HAL_UART_Transmit(&huart2, (const uint8_t*)tx, strlen((const char*)tx), 50);
		}
		else if(rx_buffer=='t')
		{
			sprintf(tx,"T: %f \r\n",Tempt);
			HAL_UART_Transmit(&huart2, (const uint8_t*)tx, strlen((const char*)tx), 50);
		}
		else if(rx_buffer=='h')
		{
			sprintf(tx,"H: %f \r\n",Humidity);
			HAL_UART_Transmit(&huart2, (const uint8_t*)tx, strlen((const char*)tx), 50);
		}
		else
		{
			sprintf(tx,"error\n");
			HAL_UART_Transmit(&huart2, (const uint8_t*)tx, strlen((const char*)tx), 50);
		}

		HAL_UART_Receive_IT(&huart2,&rx_buffer,1);
	}
}

void Oled_Proc(void)
{
	static __IO uint32_t uwtick_oled;
	if((uwTick - uwtick_oled)<50) return;
	uwtick_oled = uwTick;

	if(menu_flag==1)
	{
		sprintf((char *)oled_str,"        PARA   ");
		OLED_ShowString(0,0,(char *)oled_str,12, 0);
		sprintf((char *)oled_str,"   Humidity:%.2f    ",set_Humidity);
		if(Set_flag==0)
			OLED_ShowString(0,2,(char *)oled_str,12, 1);
		else
			OLED_ShowString(0,2,(char *)oled_str,12, 0);
		sprintf((char *)oled_str,"   Tempt:%.2f       ",set_Tempt);
		if(Set_flag==1)
			OLED_ShowString(0,4,(char *)oled_str,12, 1);
		else
			OLED_ShowString(0,4,(char *)oled_str,12, 0);
		sprintf((char *)oled_str,"   Distance: %d     ",set_Distance);
		if(Set_flag==2)
			OLED_ShowString(0,6,(char *)oled_str,12, 1);
		else
			OLED_ShowString(0,6,(char *)oled_str,12, 0);
	}
	else if(menu_flag==0)
	{
		sprintf((char *)oled_str,"        DATA   ");
		OLED_ShowString(0,0,(char *)oled_str,12, 0);
		sprintf((char *)oled_str,"   Humidity:%.2f     ",Humidity);
		OLED_ShowString(0,2,(char *)oled_str,12, 0);
		sprintf((char *)oled_str,"   Tempt:%.2f        ",Tempt);
		OLED_ShowString(0,4,(char *)oled_str,12, 0);
		sprintf((char *)oled_str,"   Distance: %d      ",Distance);
		OLED_ShowString(0,6,(char *)oled_str,12, 0);
	}

}

void Key_Proc(void)
{
	static __IO uint32_t uwtick_key;
	if((uwTick - uwtick_key)<30) return;
	uwtick_key = uwTick;
	key_val = KEY_SCAN();
	key_down = key_val & (key_old^key_val);
	key_up = ~key_val & (key_old^key_val);
	key_old = key_val;
//	if(key_down)
//	{
//		sprintf((char *)oled_str,"KEY:%d",key_down);
//		OLED_ShowString(0,0,(char *)oled_str,12, 0);
//	}

	switch(key_down)
	{
		case 1:
			Set_flag=0;
			if(menu_flag)
			{
				menu_flag=0;
				DHT11_flag=1;
			}
			else
			{
				menu_flag=1;
				DHT11_flag=0;
			}

			break;
		case 2:
			if(menu_flag==1)
			{
				Set_flag++;
				if(Set_flag>2)
					Set_flag=0;
			}


			break;
		case 3:
			if(menu_flag==1)
			{
				if(Set_flag==0)
				{
					set_Humidity++;
					if(set_Humidity>90)
						set_Humidity=0;
				}
				else if(Set_flag==1)
				{
					set_Tempt++;
					if(set_Tempt>50)
						set_Tempt=0;
				}
				else if(Set_flag==2)
				{
					set_Distance++;
					if(set_Distance>30)
						set_Distance=0;
				}
			}

			break;
		case 4:
			if(menu_flag==1)
			{
				if(Set_flag==0)
				{
					set_Humidity--;
					if(set_Humidity<0)
						set_Humidity=90;
				}
				else if(Set_flag==1)
				{
					set_Tempt--;
					if(set_Tempt<0)
						set_Tempt=50;
				}
				else if(Set_flag==2)
				{
					set_Distance--;
					if(set_Distance<0)
						set_Distance=30;
				}
			}

			break;
		default:break;
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
